# -*- coding: UTF-8 -*-
# Name: ENSOONI.py
# Description: get the NOOA oni.ascii.txt and classify the climatological phenomenas Niño, Niña and Neutral.
# Requirements: Python 3+, pandas, tabulate, numpy, missingno, sklearn
# SEAS: season, YR: year, TOTAL: average temperature, ANOM: anomaly value.


# Libraries
from datetime import datetime
from datetime import date
import requests
import os.path
import pandas as pd
import numpy as np


# General variables
url_file = 'https://www.cpc.ncep.noaa.gov/data/indices/oni.ascii.txt'
local_file = 'oni_ascii'
file_extension = '.txt'
path = 'D:/R.LTWB/.datasets/ENSOONI/'  # Your local output path, use ../.datasets/ENSOONI/ for relative path
analysis_File = 'oni_eval.csv'  # Output analysis file
threshold = 0.5


# Downloading and reading the file
file_download_text = 'File downloaded and updated = No (already exist)'
current_date = date.today()
current_date_txt = str(current_date.year).zfill(4)+str(current_date.month).zfill(2)+str(current_date.day).zfill(2)
file_request = requests.get(url_file)
file_save = path + local_file + '_' + current_date_txt + file_extension
if file_request:
    if os.path.isfile(file_save) == False:
        open(file_save, 'wb').write(file_request.content)
        file_download_text = 'File downloaded and updated = Yes'
df = pd.read_csv(file_save, sep='\s+')
print(file_download_text)
#print(df.to_markdown())

# Processing non 5 consecutive overlapping seasons
columns=['YR', 'NinaCount', 'NinoCount', 'NeutralCount', 'Eval']
df_out = pd.DataFrame(columns=columns)
start_year = df['YR'].min()
records = int(df.shape[0])
print('Records: %d\n' % records)
nina_count = 0
nino_count = 0
print('YR,NinaCount,NinoCount,NeutralCount,Eval')
for i in range (records):
    start_year_aux = df['YR'][i]
    if start_year == start_year_aux:
        if df['ANOM'][i] <= -threshold:
            nina_count += 1
        if df['ANOM'][i] >= threshold:
            nino_count += 1
    else:
        neutral_count = 12-nina_count-nino_count
        if nina_count >=5 & nina_count >= nino_count:
            Eval = 'Nina'
        if nino_count >=5 & nino_count >= nina_count:
            Eval = 'Nino'
        if neutral_count > nino_count > nina_count:
            Eval = 'Neutral'
        print('%d,%d,%d,%d,%s' % (start_year, nina_count, nino_count, neutral_count, Eval))
        df_eval = pd.DataFrame(np.array([[start_year, nina_count, nino_count, neutral_count, Eval]]), columns=columns)
        df_out = pd.concat([df_out, df_eval])
        start_year = df['YR'][i]
        nina_count = 0
        nino_count = 0
        if df['ANOM'][i] <= -threshold:
            nina_count += 1
        if df['ANOM'][i] >= threshold:
            nino_count += 1
print('%d,%d,%d,%d,%s' % (start_year, nina_count, nino_count, neutral_count, Eval))
#print(df_out)
if nina_count >= 5 & nina_count >= nino_count:
    df_out['Eval2'] = 'Nina'
if nino_count >= 5 & nino_count >= nina_count:
    df_out['Eval2'] = 'Nino'
if neutral_count > nino_count > nina_count:
    df_out['Eval2'] = 'Neutral'

print(df_out)

'''
        print('Niña events (<0.5°C): %d, Niño events (>0.5°C): %d' % (nina_count, nino_count))
        print('Processing year: %d' % df['YR'][i])    '''