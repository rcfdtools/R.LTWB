All codes are written in python.

Repository contains two folders
  1. Hydrology folder contains exercise for master and bachelor's level students with solution.
  2. project folder contains Different data analysis methods. like: wind speed and wind direction calculation by using u and v    vector data, detrending of time series data, etc.
  
I have a file named linear_model_selection_f_test.ipynb: where i used f_test  to test the significance of model and select best fit model on the basis of f-statistics. This project is not completed yet. Yours contibution to this project are welcome!
