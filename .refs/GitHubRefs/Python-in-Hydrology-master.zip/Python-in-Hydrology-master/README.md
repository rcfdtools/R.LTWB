Details
=========================================================================
*This book is written by Mr. Sat Kumar Tomer*

External links
-------------------------------------------------------------------------
*Book on [Python in Hydrology](http://www.greenteapress.com/pythonhydro/pythonhydro.html);*
*Source code is available at [code.google.com](https://code.google.com/archive/p/python-in-hydrology/source).*

License
-------------------------------------------------------------------------
*The book is available under the [GNU Free Documentation License](http://www.gnu.org/copyleft/fdl.html). If you have comments, corrections or suggestions, please send email to satkumartomer@gmail.com.*

*Translate Technical books is available under the [GNU Free Documentation License](http://www.gnu.org/copyleft/fdl.html)*

Additional Details
-------------------------------------------------------------------------
*Translate by,*
*Mr.Lai Hetao*
*yuanhengzhenli@gmail.com*