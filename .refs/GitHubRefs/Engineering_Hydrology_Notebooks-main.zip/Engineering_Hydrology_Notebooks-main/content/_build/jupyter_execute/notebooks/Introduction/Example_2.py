# This is a Title

*Italic* and **bold** text.

| Col1 | Co2 |
|---|---|
| Value | 1 |

$$\sum_{i=1}^n \alpha^i$$

s = 'this is a string 1236 & any symbol!'
i = 1

water_level = 2.3 

l = [1, 1, 0, 0, 1, 0, 0, 1]


total = 0
for n in l:
    total = total + n
    
    

l1 = [2, 2, 2]

l2 = l + l1

