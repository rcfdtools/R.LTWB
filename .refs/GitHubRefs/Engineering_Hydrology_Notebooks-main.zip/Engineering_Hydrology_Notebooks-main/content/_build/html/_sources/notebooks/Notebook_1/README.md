# Notebook 1

Open an interactive notebook in Binder:

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/dankovacek/Engineering_Hydrology_Notebooks/HEAD?filepath=Notebook_1%2FNotebook_1.ipynb)
